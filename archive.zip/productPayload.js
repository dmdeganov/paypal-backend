export const productPayload = {
  name: "Monthly subscription",
  type: "DIGITAL",
  description: "Human design monthly subscription",
  category: "SOFTWARE",
  image_url: "https://webhumandesign.site/thumb_preview.webp",
  home_url: "https://webhumandesign.site",
};
